import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import AllProducts from './components/AllProducts';

const App = () => {
  const handleLinkClick = (event) => {
    if (window.location.pathname === event.target.pathname) {
      window.location.reload();
    }
  };

  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/dashboard" onClick={handleLinkClick}>Mis Productos</Link>
            </li>
            <li>
              <Link to="/all-products" onClick={handleLinkClick}>Todos los Productos</Link>
            </li>
          </ul>
        </nav>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/all-products" element={<AllProducts />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
