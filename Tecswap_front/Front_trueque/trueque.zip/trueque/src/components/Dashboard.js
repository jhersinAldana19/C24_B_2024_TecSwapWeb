import React, { useEffect, useState } from 'react';
import AuthService from '../services/AuthService';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState('');
  const [newProduct, setNewProduct] = useState({
    titulo: '',
    descripcion: '',
    estado: 'pendiente',
    cantidad: '',
    categoria: { id: '' },
    imagen: ''
  });

  const navigate = useNavigate();
  const name = localStorage.getItem('name');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await AuthService.fetchUserProducts(); 
        setProducts(response.data);
      } catch (err) {
        setError('Error fetching products: ' + (err.response?.data || err.message));
      }
    };

    const fetchCategories = async () => {
      try {
        const response = await AuthService.fetchCategories();
        setCategories(response.data);
      } catch (err) {
        setError('Error fetching categories: ' + (err.response?.data || err.message));
      }
    };

    fetchProducts();
    fetchCategories();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    navigate('/');
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === 'categoria') {
      setNewProduct({
        ...newProduct,
        categoria: { id: value }
      });
    } else {
      setNewProduct({
        ...newProduct,
        [name]: value
      });
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    try {
      await AuthService.addProduct(newProduct);
      const response = await AuthService.fetchUserProducts();
      setProducts(response.data);
      setNewProduct({
        titulo: '',
        descripcion: '',
        estado: 'pendiente',
        cantidad: '',
        categoria: { id: '' },
        imagen: ''
      });
    } catch (err) {
      setError('Error adding product: ' + (err.response?.data || err.message));
    }
  };

  return (
    <div className="dashboard-container">
      <h2>Bienvenido, {name}</h2>
      <button onClick={handleLogout}>Logout</button>
      {error && <p>{error}</p>}

      <h3>Agregar Producto</h3>
      <form onSubmit={handleAddProduct}>
        <input
          type="text"
          name="titulo"
          value={newProduct.titulo}
          onChange={handleInputChange}
          placeholder="Título"
          required
        />
        <input
          type="text"
          name="descripcion"
          value={newProduct.descripcion}
          onChange={handleInputChange}
          placeholder="Descripción"
          required
        />
        <select
          name="estado"
          value={newProduct.estado}
          onChange={handleInputChange}
          required
        >
          <option value="pendiente">Pendiente</option>
          <option value="nuevo">Nuevo</option>
          <option value="cancelado">Cancelado</option>
        </select>
        <input
          type="number"
          name="cantidad"
          value={newProduct.cantidad}
          onChange={handleInputChange}
          placeholder="Cantidad"
          required
        />
        <select
  name="categoria"
  value={newProduct.categoria.id}
  onChange={handleInputChange}
  required
>
  <option value="">Selecciona una categoría</option>
  {categories.map((categoria) => (
    <option key={categoria.id} value={categoria.id}>
      {categoria.tipo}
    </option>
  ))}
</select>
        <input
          type="text"
          name="imagen"
          value={newProduct.imagen}
          onChange={handleInputChange}
          placeholder="URL de la imagen"
          required
        />
        <button type="submit">Agregar Producto</button>
      </form>

      <h3>Tus Productos</h3>
      <ul>
        {products.map((product) => (
          <li key={product.id}>
            {product.titulo} - {product.descripcion} (Usuario: {product.usuario.name})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;