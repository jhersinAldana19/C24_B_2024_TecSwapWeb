import React, { useEffect, useState } from 'react';
import AuthService from '../services/AuthService';

const AllProducts = () => {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await AuthService.fetchAllProducts();
        setProducts(response.data);
      } catch (err) {
        setError('Error fetching products: ' + (err.response?.data || err.message));
      }
    };
    fetchProducts();
  }, []);

  return (
    <div className="all-products-container">
      <h2>Todos los Productos</h2>
      {error && <p>{error}</p>}
      <ul>
        {products.map(product => (
          <li key={product.id}>
            {product.titulo} - {product.descripcion} (Usuario: {product.usuario.name})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AllProducts;