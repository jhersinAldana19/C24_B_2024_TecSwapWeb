import axios from 'axios';

const API_URL = 'http://localhost:8082';

const register = (name, email, password, phone, lastname, imagen, carrera) => {
  return axios.post(`${API_URL}/api/register`, {
    name,
    email,
    password,
    phone,
    lastname,
    imagen,
    carrera
  });
};

const login = async (email, password) => {
  const token = btoa(`${email}:${password}`);
  const response = await axios.post(`${API_URL}/api/login`, { email, password });
  if (response.status === 200) {
    localStorage.setItem('token', token);
    localStorage.setItem('name', response.data.name);
  }
  return response;
};

const fetchUserProducts = () => {
  const token = localStorage.getItem('token');
  return axios.get(`${API_URL}/user/products`, {
    headers: {
      'Authorization': `Basic ${token}`
    }
  });
};

const fetchCategories = () => {
  const token = localStorage.getItem('token');
  return axios.get(`${API_URL}/categorias`, {
    headers: {
      'Authorization': `Basic ${token}`
    }
  });
};

const addProduct = async (product) => {
  const token = localStorage.getItem('token');
  return axios.post(`${API_URL}/producto`, product, {
    headers: {
      'Authorization': `Basic ${token}`,
    },
  });
};

const fetchAllProducts = () => {
  return axios.get(`${API_URL}/productos`);
};

const AuthService = {
  register,
  login,
  fetchUserProducts,
  fetchAllProducts,
  addProduct,
  fetchCategories
};

export default AuthService;